Cari arti dari S0F0, Kemudian ambil 16 Byte / 32 Bit. Pastikan, Jangan ambil Size dari offset tersebut.
Hasil tadi, kalkukasi dengan XOR yang sudah di berikan. Good Luck and Enjoy :D

Flag : 435446527b7830725f773174685f7330665f63346462f56e3477324e73324e6633216582
S0F0 : ???