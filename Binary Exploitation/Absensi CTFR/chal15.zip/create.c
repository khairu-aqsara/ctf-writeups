#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

int target;

void flag() {
	char flag[64];
	FILE * f = fopen("flag", "r");
	if (f == NULL) {
		printf("File flag nya tidak ada! Kontak developer CTFR kami\n");
		exit(0);
	}
	fgets(flag, 64, f);
	printf("Here is your flag %s\n", flag);
}

void get() {
	char buff[256];
	fgets(buff, sizeof(buff), stdin);
	printf("Terima kasih sudah absensi ");
	printf(buff);
	printf("\n");
	if(target) {
		printf("Bagaimana anda bisa masuk kesini 1!1!1!...\n");
		flag();
	} else {
		// Do nothing
	}
}
int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	printf("-= Absensi CTFR =-\n");
	printf("Ketik nama anda untuk absensi: ");
	get();
}