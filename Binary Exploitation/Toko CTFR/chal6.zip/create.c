#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

void flag(unsigned int args) {
	char flag[64];
	FILE * f = fopen("flag", "r");
	if (f == NULL) {
		printf("File flag nya tidak ada! Kontak developer CTFR kami\n");
		exit(0);
	}

	fgets(flag, 64, f);
	if (args == 0) { 
		printf("=x Anda tidak dapat memanggil fungsi ini!\n");
		return;
	}
	printf("Here is your flag : %s\n", flag);
}

void get() {
	char target[32];
	gets(target);
	printf("=> Selamat Datang %s \n", target);
}
int main() {

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

    printf("= Toko Makanan CTFR =\n");
    printf("= Silahkan Input nama kalian =\n");
    get();
    return 0;
}