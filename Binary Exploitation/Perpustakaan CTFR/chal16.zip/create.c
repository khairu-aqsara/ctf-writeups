#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>

void flag() {
	char flag[64];
	FILE * f = fopen("flag", "r");
	if (f == NULL) {
		printf("File flag nya tidak ada! Kontak developer CTFR kami\n");
		exit(0);
	}
	fgets(flag, 64, f);
	puts(flag);
	_exit(1);
}

void get() {
	char target[512];
	fgets(target, sizeof(target), stdin);
	printf("=> Selamat Datang ", target);
	printf(target);
	printf("=> Pastikan Buku yang kalian pinjam jangan lupa ditaruh kembali yaa.\n");
	exit(1);
}

int main() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	printf("-= Perpustakaan CTFR =-\n");
	printf("Untuk meminjam salah satu buku di Perpustakaan ini, anda harus mengisi formulir dibawah ini.\n");
	printf("Ketik Nama anda : ");
	get();
}